#include <iostream>
#include "Tipo_Evento.h"
#include <sqlite3.h>
#include <string.h>
using namespace std;

Tipo_Evento :: Tipo_Evento (int ID_TIPO_EVENTO,string Descrizione){
	this->ID_TIPO_EVENTO=ID_TIPO_EVENTO;
	this->Descrizione=Descrizione;
}

void Tipo_Evento :: stampa(){
	cout<<"STAMPA TIPO EVENTO"<<endl;
	cout<<"ID TIPO EVENTO:"<<this->getID_TIPO_EVENTO()<<endl;
	cout<<"DESCRIZIONE:"<<this->getDescrizione()<<endl;
}

 int Tipo_Evento:: callback(void *NotUsed, int argc, char **argv, char **azColName) {
	int i;
	
	for(i = 0; i < argc; i++) {
		cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << endl;
	}
	cout << endl;
	
	return 0;
}

void Tipo_Evento :: aggiungi_tipo_evento(){
	cout << "Aggiunta tipo evento: " << endl;
	
	s.comando = "INSERT INTO TIPO_EVENTO (ID_TIPO_EVENTO, DESCRIZIONE) VALUES (?,?)";
	s.rc = sqlite3_prepare(s.database, s.comando, strlen(s.comando), &s.stmt, &s.pzTest);
	if (s.rc == SQLITE_OK) {
		sqlite3_bind_int(s.stmt, 1,this->getID_TIPO_EVENTO());
		sqlite3_bind_text(s.stmt, 2, this->getDescrizione().c_str(), strlen(this->getDescrizione().c_str()), 0);
		sqlite3_step(s.stmt);
		//log_query(sqlite3_expanded_sql(stmt));
		sqlite3_finalize(s.stmt);
		cout << "Tipo evento " << this->getID_TIPO_EVENTO()<< " inserito in tabella TIPO_EVENTO" << endl;
	} else {
		cout << "ERRORE aggiungi_tipo_evento: " << s.zErrMsg << endl;
		//log_query(zErrMsg);
		sqlite3_free(s.zErrMsg);
	}
}

void Tipo_Evento :: modifica_tipo_evento(){
	string nuovaDescrizione;
	
	cout << "Modifica tipo evento: " << endl;
		
	cout << "Nuova descrizione: ";
	getline(cin,nuovaDescrizione);
	
	this->setDescrizione(nuovaDescrizione);
	
	s.comando = "UPDATE TIPO_EVENTO SET DESCRIZIONE = ? WHERE ID_TIPO_EVENTO = ?";
	s.rc = sqlite3_prepare(s.database, s.comando, strlen(s.comando), &s.stmt, &s.pzTest);
	if (s.rc == SQLITE_OK) {
		sqlite3_bind_text(s.stmt, 1,this->getDescrizione().c_str(), strlen(this->getDescrizione().c_str()), 0);
		sqlite3_bind_int(s.stmt, 2, this->getID_TIPO_EVENTO());
		sqlite3_step(s.stmt);
		//log_query(sqlite3_expanded_sql(stmt));
		sqlite3_finalize(s.stmt);
		cout << "Tipo evento " << this->getID_TIPO_EVENTO()<< " aggiornato in tabella TIPO_EVENTI" << endl;
	} else {
		cout << "ERRORE modifica_tipo_evento: " << s.zErrMsg << endl;
		//log_query(zErrMsg);
		sqlite3_free(s.zErrMsg);
	}
	
}

void Tipo_Evento :: cancella_tipo_evento(){
	cout << "Eliminazione tipo evento: " << endl;
	
	s.comando = "DELETE FROM TIPO_EVENTO WHERE ID_TIPO_EVENTO = ?";
	s.rc = sqlite3_prepare(s.database, s.comando, strlen(s.comando), &s.stmt, &s.pzTest);
	if (s.rc == SQLITE_OK) {
		sqlite3_bind_int(s.stmt, 1, this->getID_TIPO_EVENTO());
		sqlite3_step(s.stmt);
		//log_query(sqlite3_expanded_sql(stmt));
		sqlite3_finalize(s.stmt);
		cout << "Tipo evento " << this->getID_TIPO_EVENTO() << " cancellato da tabella TIPO_EVENTO" << endl;
	} else {
		cout << "ERRORE cancella_tipo_evento: " << s.zErrMsg << endl;
		//log_query(zErrMsg);
		sqlite3_free(s.zErrMsg);
	}
}
