#include <iostream>
using namespace std;
#include <sqlite3.h>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <ctime>
#include <Persona.h>
#include <Tipo_Evento.h>
#include <Evento.h>
#include <Sqlite.h>
#define DIM 100



void mostra_eventi(Sqlite &s);
void mostra_tipo_evento(Sqlite &s);
void mostra_eventi_IDtipo(Sqlite &s);
void mostra_eventi_ordine_cronologico(Sqlite &s);
void mostra_persone(Sqlite &s);
static int callback(void *NotUsed, int argc, char **argv, char **azColName) ;
void log_query(const char* txt);
string orario();

int main(int argc, char **argv) {

	Sqlite s;

	ofstream log; // Pulizia log prima di nuova esecuzione programma
	log.open("query.log"); 
	if (!log.is_open()) {
		cout << "Impossibile creare il log!" << endl;
		return 0;
	}
	log.close();
	

	s.rc = sqlite3_open("database.sqlite", &s.database);
	if (s.rc != SQLITE_OK) {
		cout << "ERRORE nell'apertura del database: " << sqlite3_errmsg(s.database) << endl;
		log_query("ERRORE nell'apertura del database: ");
		log_query(sqlite3_errmsg(s.database));
		return -1;
	} else {
		cout << "Database aperto" << endl << endl;
		log_query("Database aperto");
	}
	
	s.comando = "CREATE TABLE IF NOT EXISTS PERSONE (ID_PERSONA INTEGER, NOME STRING, COGNOME STRING)";
	log_query(s.comando);
	s.rc = sqlite3_exec(s.database, s.comando, callback, 0, &s.zErrMsg);
	if (s.rc != SQLITE_OK) {
		cout << "ERRORE tabella PERSONE: " << s.zErrMsg << endl;
		log_query("ERRORE tabella PERSONE: ");
		log_query(s.zErrMsg);
		sqlite3_free(s.zErrMsg);
		return -1;
	} else {
		cout << "Tabella PERSONE pronta" << endl;
	}
	
	s.comando = "CREATE TABLE IF NOT EXISTS TIPO_EVENTO (ID_TIPO_EVENTO INTEGER, DESCRIZIONE STRING)";
	log_query(s.comando);
	s.rc = sqlite3_exec(s.database, s.comando, callback, 0, &s.zErrMsg);
	if (s.rc != SQLITE_OK) {
		cout << "ERRORE tabella TIPO_EVENTO: " << s.zErrMsg << endl;
		log_query("ERRORE tabella TIPO_EVENTO: ");
		log_query(s.zErrMsg);
		sqlite3_free(s.zErrMsg);
		return -1;
	} else {
		cout << "Tabella TIPO_EVENTO pronta" << endl;
	}
	
	s.comando = "CREATE TABLE IF NOT EXISTS EVENTI (ID_PERSONA INTEGER, ID_TIPO_EVENTO INTEGER, DATA_ORA_EVENTO DATETIME)";
	log_query(s.comando);
	s.rc = sqlite3_exec(s.database, s.comando, callback, 0, &s.zErrMsg);
	if (s.rc != SQLITE_OK)  {
		cout << "ERRORE tabella EVENTI: " << s.zErrMsg << endl;
		log_query("ERRORE tabella EVENTI:");
		log_query(s.zErrMsg);
		sqlite3_free(s.zErrMsg);
		return -1;
	} else {
		cout << "Tabella EVENTI pronta" << endl;
	}
	
	Persona p(1,"usv","klrnttg");
	p.assegnaSqlite(s);
	Tipo_Evento t;
	t.assegnaSqlite(s);
	Evento e;
	e.assegnaSqlite(s);
	string nome;
	string cognome;
	int id_persona;
	int id_tipo_evento;
	string descrizione;
	string data_ora_evento;
	int scelta = 0;
	
	cout << endl << "\tOPZIONI DISPONIBILI:" << endl << endl;
		
	cout << "\t1. Aggiungi persona" << endl;
	cout << "\t2. Modifica persona" << endl;
	cout << "\t3. Cancella persona" << endl;
	cout << "\t4. Aggiungi tipo evento" << endl;
	cout << "\t5. Modifica tipo evento" << endl;
	cout << "\t6. Cancella tipo evento" << endl;
	cout << "\t7. Aggiungi evento" << endl;
	cout << "\t8. Modifica evento" << endl;
	cout << "\t9. Elimina evento" << endl;
	cout << "\t10. Mostra tabella persone" << endl;
	cout << "\t11. Mostra tabella tipo evento" << endl;
	cout << "\t12. Mostra tabella eventi" << endl;
	cout << "\t13. Estrai eventi in ordine cronologico relativi ad una persona" << endl;
	cout << "\t14. Estrai eventi dato ID tipo evento" << endl;
	
	cout << endl << "\tSCELTA: ";
	cin >> scelta;
	cout << endl;
	
	switch (scelta) {
		case 1:
			cout<<"Inserisci id persona:";
			cin>>id_persona;
			while(cin.get()!='\n');
			
			cout<<"Inserisci cognome persona:";
			getline(cin,cognome);
			
			cout<<"Inserici nome persona:";
			getline(cin,nome);
			
			p.setNome(nome);
			p.setCognome(cognome);
			p.setID_PERSONA(id_persona);
			p.aggiungi_persona();
			break;
		case 2:
			p.modifica_persona();
			break;
		case 3:
			p.cancella_persona();
			break;
		case 4:
			cout<<"Inserisci id tipo evento:";
			cin>>id_tipo_evento;
			while(cin.get()!='\n');
			
			cout<<"Inserisci descrizione:";
			getline(cin,descrizione);
			
			t.setID_TIPO_EVENTO(id_tipo_evento);
			t.setDescrizione(descrizione);
			t.aggiungi_tipo_evento();
			break;
		case 5:
			t.modifica_tipo_evento();
			break;
		case 6:
			t.cancella_tipo_evento();
			break;
		case 7:
			cout<<"Inserisci id della persona:";
			cin>>id_persona;
			while(cin.get()!='\n');
			
			cout<<"Inserisci id tipo evento:";
			cin>>id_tipo_evento;
			while(cin.get()!='\n');
			
			cout<<"Inserisci data  e ora evento:";
			getline(cin,data_ora_evento);
			
			e.SetDATA_ORA_EVENTO(data_ora_evento);
			e.SetID_PERSONA(id_persona);
			e.SetID_TIPO_EVENTO(id_tipo_evento);
			e.aggiungi_evento();
			break;
		case 8:
			e.modifica_evento();
			break;
		case 9:
			e.cancella_evento();
			break;
		case 10:
			mostra_persone(s);
			break;
		case 11:
			mostra_tipo_evento(s);
			break;
		case 12:
			mostra_eventi(s);
			break;
		case 13:
			mostra_eventi_ordine_cronologico(s);
			break;
		case 14:
			mostra_eventi_IDtipo(s);
			break;
		default:
			cout << "SCELTA NON VALIDA!" << endl;
			break;
	}

	return 0;

}


static int callback(void *NotUsed, int argc, char **argv, char **azColName) {
	int i;
	
	for(i = 0; i < argc; i++) {
		cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << endl;
	}
	cout << endl;
	
	return 0;
}


void mostra_persone(Sqlite &s) {
	cout << "Lettura tabella Persone: " << endl;
	
	int i = 0;
	int row = 1;
	int bytes1 = 0;
	int bytes2 = 0;
	int bytes3 = 0;
	const unsigned char * text1;
	const unsigned char * text2;
	const unsigned char * text3;
	
	s.comando = "SELECT * FROM PERSONE";
	s.rc = sqlite3_prepare(s.database, s.comando, strlen(s.comando), &s.stmt, &s.pzTest);
	if (s.rc != SQLITE_OK) {
		cout << "ERRORE mostra_persone: " << s.zErrMsg << endl;
		log_query(s.zErrMsg);
		sqlite3_free(s.zErrMsg);
	}
	
	cout << "ID\t\tNOME\t\tCOGNOME" << endl;
	
	while (1) {
		
		int s1;
		s1 = sqlite3_step (s.stmt);
		
		if (s1 == SQLITE_ROW) {
			bytes1 = sqlite3_column_bytes(s.stmt, 0);
			text1 = sqlite3_column_text(s.stmt, 0);
			
			bytes2 = sqlite3_column_bytes(s.stmt, 1);
			text2 = sqlite3_column_text(s.stmt, 1);
			
			bytes3 = sqlite3_column_bytes(s.stmt, 2);
			text3 = sqlite3_column_text(s.stmt, 2);
			
			cout << text1 << "\t\t" << text2 << "\t\t" << text3 << endl;
			row++;
		}
		else if (s1 == SQLITE_DONE) {
			break;
		}
		else {
			cout << "ERRORE" << endl;
			return;
		}
		
	}
	
	log_query(sqlite3_expanded_sql(s.stmt));
	
	sqlite3_finalize(s.stmt);
	
	cout << "Fine lettura tabella Persone" << endl;
	
	return;
	
}

void mostra_tipo_evento(Sqlite &s) {
	cout << "Lettura tabella Tipo evento: " << endl;
	
	int i = 0;
	int row = 1;
	int bytes1 = 0;
	int bytes2 = 0;
	const unsigned char * text1;
	const unsigned char * text2;
	
	s.comando = "SELECT * FROM TIPO_EVENTO";
	s.rc = sqlite3_prepare(s.database, s.comando, strlen(s.comando), &s.stmt, &s.pzTest);
	if (s.rc != SQLITE_OK) {
		cout << "ERRORE mostra_tipo_evento: " << s.zErrMsg << endl;
		log_query(s.zErrMsg);
		sqlite3_free(s.zErrMsg);
	}
	
	cout << "TIPO EVENTO\tDESCRIZIONE" << endl;
	
	while (1) {
		
		int s1;
		s1 = sqlite3_step (s.stmt);
		
		if (s1 == SQLITE_ROW) {
			bytes1 = sqlite3_column_bytes(s.stmt, 0);
			text1 = sqlite3_column_text(s.stmt, 0);
			
			bytes2 = sqlite3_column_bytes(s.stmt, 1);
			text2 = sqlite3_column_text(s.stmt, 1);
			
			cout << text1 << "\t\t" << text2 << endl;
			row++;
		}
		else if (s1 == SQLITE_DONE) {
			break;
		}
		else {
			cout << "ERRORE" << endl;
			return;
		}
		
	}
	
	log_query(sqlite3_expanded_sql(s.stmt));
	
	sqlite3_finalize(s.stmt);
	
	cout << "Fine lettura tabella Tipo evento" << endl;
	
	return;
	
}

void mostra_eventi(Sqlite &s) {
	cout << "Lettura tabella Eventi: " << endl;
	
	int i = 0;
	int row = 1;
	int bytes1 = 0;
	int bytes2 = 0;
	int bytes3 = 0;
	const unsigned char * text1;
	const unsigned char * text2;
	const unsigned char * text3;
	
	s.comando = "SELECT * FROM EVENTI";
	s.rc = sqlite3_prepare(s.database, s.comando, strlen(s.comando), &s.stmt, &s.pzTest);
	if (s.rc != SQLITE_OK) {
		cout << "ERRORE mostra_eventi: " << s.zErrMsg << endl;
		log_query(s.zErrMsg);
		sqlite3_free(s.zErrMsg);
	}
	
	cout << "PERSONA\t\tTIPO EVENTO\t\DATA-ORA" << endl;
	
	while (1) {
		
		int s1;
		s1 = sqlite3_step (s.stmt);
		
		if (s1 == SQLITE_ROW) {
			bytes1 = sqlite3_column_bytes(s.stmt, 0);
			text1 = sqlite3_column_text(s.stmt, 0);
			
			bytes2 = sqlite3_column_bytes(s.stmt,1);
			text2 = sqlite3_column_text(s.stmt, 1);
			
			bytes3 = sqlite3_column_bytes(s.stmt,2);
			text3 = sqlite3_column_text(s.stmt, 2);
			
			cout << text1 << "\t\t" << text2 << "\t\t" << text3 << endl;
			row++;
		}
		else if (s1 == SQLITE_DONE) {
			break;
		}
		else {
			cout << "ERRORE" << endl;
			return;
		}
		
	}
	
	log_query(sqlite3_expanded_sql(s.stmt));
	
	sqlite3_finalize(s.stmt);
	
	cout << "Fine lettura tabella Eventi" << endl;
	
	return;
	
}

void mostra_eventi_ordine_cronologico(Sqlite &s) {
	cout << "Elenco cronologico degli eventi: " << endl;
	
	int ID_PERSONA = 0;
	cout << "ID persona di cui vedere gli eventi: " ;
	cin >> ID_PERSONA;
	
	int i = 0;
	int row = 1;
	int bytes1 = 0;
	int bytes2 = 0;
	int bytes3 = 0;
	const unsigned char * text1;
	const unsigned char * text2;
	const unsigned char * text3;
	
	s.comando = "SELECT * FROM EVENTI WHERE ID_PERSONA = ? ORDER BY DATA_ORA_EVENTO ASC";
	s.rc = sqlite3_prepare(s.database, s.comando, strlen(s.comando), &s.stmt, &s.pzTest);
	
	if (s.rc != SQLITE_OK) {
		cout << "ERRORE mostra_eventi_ordine_cronologico: " << s.zErrMsg << endl;
		log_query(s.zErrMsg);
		sqlite3_free(s.zErrMsg);
		return;
	}
	
	sqlite3_bind_int(s.stmt,1, ID_PERSONA);
	
	cout << "ID persona\tID tipo evento\tData/ora" << endl;
	
	while (1) {
		
		int s1;
		s1 = sqlite3_step (s.stmt);
		
		if (s1 == SQLITE_ROW) {
			bytes1 = sqlite3_column_bytes(s.stmt, 0);
			text1 = sqlite3_column_text (s.stmt, 0);
			
			bytes2 = sqlite3_column_bytes(s.stmt, 1);
			text2 = sqlite3_column_text (s.stmt, 1);
			
			bytes3 = sqlite3_column_bytes(s.stmt, 2);
			text3 = sqlite3_column_text (s.stmt, 2);
			
			cout << text1 << "\t\t" << text2 << "\t\t" << text3 << endl;
			row++;
		}
		else if (s1 == SQLITE_DONE) {
			break;
		}
		else {
			cout << "ERRORE" << endl;
			return;
		}
		
	}
	
	log_query(sqlite3_expanded_sql(s.stmt));
	
	sqlite3_finalize(s.stmt);
	
	cout << "Fine lettura" << endl;
	
	delete text1;
	delete text2;
	delete text3;
	
	return;
}

void mostra_eventi_IDtipo(Sqlite &s) {
	cout << "Elenco degli eventi dato ID: " << endl;
	
	int ID_TIPO_EVENTO = 0;
	cout << "ID tipo di evento da visualizzare: " ;
	cin >> ID_TIPO_EVENTO;
	
	cout << "Elenco degli eventi con ID tipo " << ID_TIPO_EVENTO << endl;
	
	int i = 0;
	int row = 1;
	int bytes1 = 0;
	int bytes2 = 0;
	int bytes3 = 0;
	const unsigned char * text1;
	const unsigned char * text2;
	const unsigned char * text3;
	
	s.comando = "SELECT * FROM EVENTI WHERE ID_TIPO_EVENTO = ? ORDER BY DATA_ORA_EVENTO ASC";
	s.rc = sqlite3_prepare(s.database, s.comando, strlen(s.comando), &s.stmt, &s.pzTest);
	
	if (s.rc != SQLITE_OK) {
		cout << "ERRORE mostra_eventi_IDtipo: " << s.zErrMsg << endl;
		log_query(s.zErrMsg);
		sqlite3_free(s.zErrMsg);
		return;
	}
	
	sqlite3_bind_int(s.stmt, 1, ID_TIPO_EVENTO);
	
	cout << "ID persona\tID tipo evento\tData/ora" << endl;
	
	while (1) {
		
		int s1;
		s1 = sqlite3_step (s.stmt);
		
		if (s1== SQLITE_ROW) {
			bytes1 = sqlite3_column_bytes(s.stmt, 0);
			text1 = sqlite3_column_text (s.stmt, 0);
			
			bytes2 = sqlite3_column_bytes(s.stmt, 1);
			text2 = sqlite3_column_text (s.stmt, 1);
			
			bytes3 = sqlite3_column_bytes(s.stmt, 2);
			text3 = sqlite3_column_text (s.stmt, 2);
			
			cout << text1 << "\t\t" << text2 << "\t\t" << text3 << endl;
			row++;
		}
		else if (s1 == SQLITE_DONE) {
			break;
		}
		else {
			cout << "ERRORE" << endl;
			return;
		}
		
	}
	
	log_query(sqlite3_expanded_sql(s.stmt));
	
	sqlite3_finalize(s.stmt);
	
	cout << "Fine lettura" << endl;
	
	delete text1;
	delete text2;
	delete text3;
	
	return;
}

void log_query(const char* txt) {
	ofstream log;
	
	log.open("query.log",ios::app); 
	if (!log.is_open()) {
		cout << "Impossibile creare il log!" << endl;
		return;
	}
	log << orario() << " - " << txt << endl;
	log.close();
}

string orario() {
	time_t rawtime;
	struct tm * timeinfo;
	char buffer[DIM];
	time (&rawtime);
	timeinfo = localtime(&rawtime);
	strftime(buffer,sizeof(buffer),"%Y-%m-%d %H:%M:%S",timeinfo);
	string str(buffer);
	return str;
}