#include <iostream>
#include "Evento.h"
#include <sqlite3.h>
#include <string.h>
#include <Sqlite.h>
using namespace std;


Evento :: Evento(int ID_PERSONA,int ID_TIPO_EVENTO,string DATA_ORA_EVENTO){
	this->ID_PERSONA=ID_PERSONA;
	this->ID_TIPO_EVENTO=ID_TIPO_EVENTO;
	this->DATA_ORA_EVENTO=DATA_ORA_EVENTO;
}

void Evento :: stampa(){
	cout<<"Stampa Evento"<<endl;
	cout<<"ID PERSONA:"<<this->GetID_PERSONA()<<endl;
	cout<<"ID TIPO EVENTO:"<<this->GetID_TIPO_EVENTO()<<endl;
	cout<<"DATA E ORA EVENTO:"<<this->GetDATA_ORA_EVENTO()<<endl;
}
int Evento:: callback(void *NotUsed, int argc, char **argv, char **azColName) {
	int i;
	
	for(i = 0; i < argc; i++) {
		cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << endl;
	}
	cout << endl;
	
	return 0;
}

void Evento :: aggiungi_evento(){

	cout << "Inserimento evento: " << endl;
	
	s.comando = "INSERT INTO EVENTI (ID_PERSONA, ID_TIPO_EVENTO, DATA_ORA_EVENTO) VALUES (?,?,?)";
	s.rc = sqlite3_prepare(s.database, s.comando, strlen(s.comando), &s.stmt, &s.pzTest);
	if (s.rc == SQLITE_OK) {
		sqlite3_bind_int(s.stmt, 1,this->GetID_PERSONA());
		sqlite3_bind_int(s.stmt, 2, this->GetID_TIPO_EVENTO());
		sqlite3_bind_text(s.stmt, 3, this->GetDATA_ORA_EVENTO().c_str(),strlen(this->GetDATA_ORA_EVENTO().c_str()), 0);
		sqlite3_step(s.stmt);
		//log_query(sqlite3_expanded_sql(stmt));
		sqlite3_finalize(s.stmt);
		cout << "Evento inserito in tabella EVENTI" << endl;
	} else {
		cout << "ERRORE aggiungi_evento: " << s.zErrMsg << endl;
		//log_query(zErrMsg);
		sqlite3_free(s.zErrMsg);
	}
}

void Evento :: modifica_evento(){
	int  NEW_ID_TIPO_EVENTO;
	string NEW_DATA_ORA_EVENTO;
	
	cout << "Modifica evento: " << endl;
	
	cout << "Nuovo ID tipo evento: ";
	cin >> NEW_ID_TIPO_EVENTO;
	while(cin.get()!='\n');
	
	cout << "Nuova data/ora evento: ";
	getline(cin,NEW_DATA_ORA_EVENTO);
	
	s.comando = "UPDATE EVENTI SET ID_TIPO_EVENTO = ?, DATA_ORA_EVENTO = ? WHERE ID_PERSONA = ? AND ID_TIPO_EVENTO = ? AND DATA_ORA_EVENTO = ?";
	s.rc = sqlite3_prepare(s.database, s.comando, strlen(s.comando), &s.stmt, &s.pzTest);
	if (s.rc == SQLITE_OK) {
		sqlite3_bind_int(s.stmt, 1, NEW_ID_TIPO_EVENTO);
		sqlite3_bind_text(s.stmt, 2, NEW_DATA_ORA_EVENTO.c_str(), strlen(NEW_DATA_ORA_EVENTO.c_str()), 0);
		sqlite3_bind_int(s.stmt, 3,this->GetID_PERSONA());
		sqlite3_bind_int(s.stmt, 4,this->GetID_TIPO_EVENTO());
		sqlite3_bind_text(s.stmt, 5, this->GetDATA_ORA_EVENTO().c_str(), strlen(this->GetDATA_ORA_EVENTO().c_str()), 0);
		sqlite3_step(s.stmt);
		cout<<sqlite3_expanded_sql(s.stmt);
		sqlite3_finalize(s.stmt);
		cout << "Evento aggiornato in tabella EVENTI" << endl;
	} else {
		cout << "ERRORE modifica_evento: " << s.zErrMsg << endl;
		cout<<s.zErrMsg;
		sqlite3_free(s.zErrMsg);
	}
	
	
	this->SetDATA_ORA_EVENTO(NEW_DATA_ORA_EVENTO);
	this->SetID_TIPO_EVENTO(NEW_ID_TIPO_EVENTO);
	cout<<this->GetDATA_ORA_EVENTO()<<endl;
}
void Evento ::  cancella_evento(){
	cout << "Eliminazione evento: " << endl;
	
	s.comando = "DELETE FROM EVENTI WHERE ID_PERSONA = ? AND ID_TIPO_EVENTO = ? AND DATA_ORA_EVENTO = ?";
	s.rc = sqlite3_prepare(s.database, s.comando, strlen(s.comando), &s.stmt, &s.pzTest);
	if (s.rc == SQLITE_OK) {
		sqlite3_bind_int(s.stmt, 1, this->GetID_PERSONA());
		sqlite3_bind_int(s.stmt, 2, this->GetID_TIPO_EVENTO());
		sqlite3_bind_text(s.stmt, 3, this->GetDATA_ORA_EVENTO().c_str(), strlen(this->GetDATA_ORA_EVENTO().c_str()), 0);
		sqlite3_step(s.stmt);
		cout<<sqlite3_expanded_sql(s.stmt);
		sqlite3_finalize(s.stmt);
		cout << "Evento cancellato da tabella EVENTI" << endl;
	} else {
		cout << "ERRORE cancella_evento: " << s.zErrMsg << endl;
		cout<<s.zErrMsg;
		sqlite3_free(s.zErrMsg);
	}
}

