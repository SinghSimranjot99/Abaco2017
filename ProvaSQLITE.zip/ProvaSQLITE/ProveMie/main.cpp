#include <iostream>
#include <string.h>

using namespace std;
int main(int argc, char **argv)
{
	string s="Ciao";
	const char *s1=s.c_str();
	getline(cin,s);
	cout<<s<<endl;
	return 0;
}
